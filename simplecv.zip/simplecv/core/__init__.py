from simplecv.core.config import AttrDict
from simplecv.core.trainer import Launcher
from simplecv.core.trainer import LauncherPlugin
