"""
Closed source
"""
